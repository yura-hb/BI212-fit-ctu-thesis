#define STATIC_VECTOR
#define VECTOR_OF_STATIC_VECTORS
#include "VectorBinaryOperationsTest.h"
#include "VectorUnaryOperationsTest.h"
#include "VectorVerticalOperationsTest.h"
#include "../main.h"
