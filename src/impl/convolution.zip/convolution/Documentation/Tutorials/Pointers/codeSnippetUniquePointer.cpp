template< typename Object, typename Device = typename Object::DeviceType >
class UniquePointer;