auto compressedRowLengths = [=] __cuda_callable__ (
    Index rows,
    Index columns,
    Index row ) -> Index;