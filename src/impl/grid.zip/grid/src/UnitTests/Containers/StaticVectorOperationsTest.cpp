#define STATIC_VECTOR
#include "VectorBinaryOperationsTest.h"
#include "VectorUnaryOperationsTest.h"
#include "VectorVerticalOperationsTest.h"
#include "../main.h"
