#define DISTRIBUTED_VECTOR
#include "VectorVerticalOperationsTest.h"
#include "../main_mpi.h"
