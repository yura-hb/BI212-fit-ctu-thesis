#define DISTRIBUTED_VECTOR
#include "VectorBinaryOperationsTest.h"
#include "../main_mpi.h"
