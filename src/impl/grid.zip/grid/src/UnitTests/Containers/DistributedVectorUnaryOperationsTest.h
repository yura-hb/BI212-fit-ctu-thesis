#define DISTRIBUTED_VECTOR
#include "VectorUnaryOperationsTest.h"
#include "../main_mpi.h"
