// conversion has to be registered for each object file
#include "tnl_str_conversion.h"
#include "tnl_tuple_conversion.h"
#include "variant_caster.h"
#include "iostream_caster.h"
