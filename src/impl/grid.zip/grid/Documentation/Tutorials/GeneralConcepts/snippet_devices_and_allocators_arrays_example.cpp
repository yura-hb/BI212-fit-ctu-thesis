TNL::Containers::Array< int, TNL::Devices::Host > host_array;
TNL::Containers::Array< int, TNL::Devices::Cuda > cuda_array;