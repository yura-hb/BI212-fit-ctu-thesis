host_array.setSize( 10 );
cuda_array.setSize( 10 );