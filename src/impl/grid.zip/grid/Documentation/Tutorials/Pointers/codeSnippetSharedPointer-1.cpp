struct Array
{
   double* data;
   int size;
};

