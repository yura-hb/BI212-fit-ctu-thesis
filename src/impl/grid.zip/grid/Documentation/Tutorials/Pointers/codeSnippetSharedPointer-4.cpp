struct ArrayTuple
{
   Array *a1, *a2;
}