#include <iostream>
#include <TNL/Math.h>

using namespace TNL;
using namespace std;
       
int main()
{
    isPow2(1024);
    roundUpDivision(10,4);
}